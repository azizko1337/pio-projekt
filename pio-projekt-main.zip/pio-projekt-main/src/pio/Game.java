package pio;


import java.util.Random;


public class Game {
    public static void main(String[] args) {
    	final boolean auto = false;
        Random rand = new Random();     
//        Player player = new Player();
        PlayerHuman player = new PlayerHuman("Stefan");
       //9 player.setName("Automat losujacy");
        
        int number;  
        int guess;                      

        do {
            System.out.println("---------------------");

            number = rand.nextInt(6) + 1;
            System.out.println("Kostka: " + number);

            guess = player.guess();
            System.out.println("Gracz \'" + player.getName() + "\' wylosowal: " + guess);

            if (number != guess) {
                System.out.println("PUDŁO!");
            }
            else {
                System.out.println("BRAWO!");
            }

        } while (number != guess);
    }

}

//dry, open closed