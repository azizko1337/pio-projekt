package pio;

import java.util.Scanner;

public class PlayerHuman extends Player {
	final private Scanner in = new Scanner(System.in);
	
	PlayerHuman(){}
	PlayerHuman(String name){
		super(name);
	}
	
	@Override
	public int guess() {
		System.out.print("Podaj strzal: ");
		return in.nextInt();
	}
}